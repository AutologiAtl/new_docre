from django.apps import AppConfig


class PdfExtracterAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Pdf_Extracter_app'
